
# API First 를 위한 Project 예제

```shell
./gradlew clean :masilcodegen:build :app:build

```