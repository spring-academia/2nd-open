package com.fastcampus.pickingTDD.Entity;

public class Sku {
}
