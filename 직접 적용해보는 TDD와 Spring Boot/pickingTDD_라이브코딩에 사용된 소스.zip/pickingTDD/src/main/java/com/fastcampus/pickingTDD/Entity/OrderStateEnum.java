package com.fastcampus.pickingTDD.Entity;

public enum OrderStateEnum {
  ORDERED, LISTMADED, ASSIGNED, PENDING, PICKING, DONE
}
