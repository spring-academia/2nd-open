package com.fastcampus.pickingTDD.Entity;

public enum PickingStateEnum {
  NOTASSIGNED, ASSIGNED, PROGRESS, PENDING, ERROR, DONE
}
