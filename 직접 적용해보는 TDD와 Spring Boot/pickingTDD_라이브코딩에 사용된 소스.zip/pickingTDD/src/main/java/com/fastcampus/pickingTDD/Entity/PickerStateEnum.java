package com.fastcampus.pickingTDD.Entity;

public enum PickerStateEnum {
  REST, ASSIGNED, PROCESS, PENDING, ERROR, DONE
}
