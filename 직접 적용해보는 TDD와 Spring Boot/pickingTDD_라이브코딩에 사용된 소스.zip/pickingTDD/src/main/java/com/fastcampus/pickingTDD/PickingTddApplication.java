package com.fastcampus.pickingTDD;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PickingTddApplication {

	public static void main(String[] args) {
		SpringApplication.run(PickingTddApplication.class, args);
	}

}
