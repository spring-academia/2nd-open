package com.example.springaop;

public @interface AlarmGreetingMachine {
}
