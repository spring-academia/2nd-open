package com.example.springaop;

public abstract class StoreAbstract {
    abstract void visitedBy(User user);

    abstract boolean isVIP(User user);
}
