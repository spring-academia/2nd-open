package com.example.springaop;

import org.springframework.stereotype.Component;

@Component
public class Store extends StoreAbstract {
    private String name;

    private int visitCountByUser = 0;

    public String getOperationTime() {
        return "AM 08:00 ~ PM 08:00";
    }

    @AlarmGreetingMachine
    public void visitedBy(User user) {
        // 핵심 1
        greeting();
        visitCountByUser++;
    }

    public boolean isVIP(User user) {
        return visitCountByUser > 10;
    }

    public void setVisitCountByUser(int visitCountByUser) {
        this.visitCountByUser = visitCountByUser;
    }

    private void greeting() {
        System.out.println("어서 오세요!");

//        IGreetingMachine greetingMachine = new GreetingMachineProxy();
//        greetingMachine.greet(user);

//        IGreetingMachine greetingMachine = new AlarmGreetingMachineDecorator(
//            new DancingGreetingMachineDecorator(new GreetingMachine())
//        );
//
//        greetingMachine.greet(user);
    }
}
