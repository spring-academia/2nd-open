package com.example.springaop;

public interface IGreetingMachine {
    void greet(User user);
}
