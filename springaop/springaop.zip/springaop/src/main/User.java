
class User {
    private String name;

    private String email;
}
