package com.example.springaop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
public class StoreTest {
    @Test
    public void test() {
        // Given
        Store store = new Store();

        // When & Then
        assertThat(store.getOperationTime()).isEqualTo("AM 08:00 ~ PM 08:00");
    }

    @Test
    public void isVIPUser() {
        // Given
        Store store = new Store();
        store.setVisitCountByUser(11);

        // When
        boolean result = store.isVIP(new User());

        // Then
        assertThat(result).isTrue();
    }
}
