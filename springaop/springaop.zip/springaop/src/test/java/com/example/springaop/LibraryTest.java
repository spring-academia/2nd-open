package com.example.springaop;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;

@SpringBootTest
public class LibraryTest {
    @Autowired
    private Library library;

    @Test
    public void test() {
        // Given
        Library library = new Library();
        library.setName("행복 도서관");

        // When
        String result = library.getName();

        // Then
        assertThat(result).isNotNull();
        assertThat(result).isEqualTo("행복 도서관");
    }

    @Test
    public void testVisitedBy() {
        // Given
        library.setName("행복 도서관");

        User user = new User();
        user.setName("스프링");

        // When
        library.visitedBy(user);

        // Then
    }
}
