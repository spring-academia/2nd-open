package com.fastcampus.inventoryTDD;

public enum InventoryTypeEnum {
  NORMAL, COLD, FROZEN
}
