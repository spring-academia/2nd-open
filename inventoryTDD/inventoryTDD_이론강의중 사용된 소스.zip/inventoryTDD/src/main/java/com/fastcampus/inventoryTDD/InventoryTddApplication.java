package com.fastcampus.inventoryTDD;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InventoryTddApplication {

	public static void main(String[] args) {
		SpringApplication.run(InventoryTddApplication.class, args);
	}

}
